Excel-DNA Samples
=================

This directory contains various .dna files, each of which is a salf-contained add-in that exhibit some Excel-DNA functionality.

The .dna files a .xml files that can be edited with a regular text editor.

To run any of the sample .dna files, make a copy of the Distribution\ExcelDna.xll file, place it next to the .dna file, and rename to have the same prefix. E.g. to run Optional.dna, make a copy of ExcelDna.xll called Optional.xll, and double-click, or File->Open to load in Excel.
